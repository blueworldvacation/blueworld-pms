create table if not exists owners (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  bank_account text,
  created_at timestamptz default now()
);

create table if not exists properties (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  property_type text default 'apartment',
  city text default 'Dibba Fujairah',
  bedrooms int default 1,
  bathrooms int default 1,
  max_guests int default 2,
  nightly_rate numeric default 0,
  status text default 'available',
  owner_id uuid references owners(id),
  booking_url text,
  airbnb_url text,
  created_at timestamptz default now()
);

create table if not exists guests (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  nationality text,
  created_at timestamptz default now()
);

create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  property_id uuid references properties(id),
  guest_id uuid references guests(id),
  source text default 'direct',
  check_in date not null,
  check_out date not null,
  nights int,
  total_amount numeric default 0,
  commission numeric default 0,
  net_amount numeric default 0,
  payment_status text default 'unpaid',
  booking_status text default 'confirmed',
  created_at timestamptz default now()
);

create table if not exists income (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references bookings(id),
  property_id uuid references properties(id),
  income_date date not null,
  source text,
  amount numeric not null default 0,
  notes text,
  created_at timestamptz default now()
);

create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  property_id uuid references properties(id),
  expense_date date not null,
  category text not null,
  amount numeric not null default 0,
  notes text,
  created_at timestamptz default now()
);

create table if not exists maintenance (
  id uuid primary key default gen_random_uuid(),
  property_id uuid references properties(id),
  title text not null,
  status text default 'open',
  cost numeric default 0,
  reported_at date default current_date,
  notes text,
  created_at timestamptz default now()
);
